/* ====== DADOS EDITÁVEIS ======
   Troque o número do WhatsApp (somente dígitos, com 55 + DDD).
   Exemplo: "5527999999999". Enquanto estiver vazio, o botão abre
   o WhatsApp para escolher o contato. */
const CONFIG = {
  whatsapp: "",
  mensagem: "Olá! Vim pelo site e quero agendar nagô natural.",
  precos: [
    { qtd: "Até 30 tranças",      valor: 50 },
    { qtd: "31 a 50 tranças",     valor: 70 },
    { qtd: "51 a 70 tranças",     valor: 90 },
    { qtd: "71 a 90 tranças",     valor: 110 },
    { qtd: "Acima de 90 tranças", valor: 130 }
  ]
};

/* WhatsApp */
const numero = CONFIG.whatsapp.replace(/\D/g, "");
const linkZap = "https://wa.me/" + numero + "?text=" + encodeURIComponent(CONFIG.mensagem);
document.querySelectorAll("[data-whatsapp]").forEach(a => {
  a.href = linkZap;
  a.target = "_blank";
  a.rel = "noopener";
});

/* Tabela de preços */
const lista = document.getElementById("tabela-precos");
CONFIG.precos.forEach(p => {
  const li = document.createElement("li");
  const valor = p.valor.toLocaleString("pt-BR", { minimumFractionDigits: 2 });
  li.innerHTML = '<span class="qtd"></span><span class="pontos" aria-hidden="true"></span>' +
                 '<span class="valor"><small>R$</small>' + valor + '</span>';
  li.querySelector(".qtd").textContent = p.qtd;
  lista.appendChild(li);
});

/* Galeria com ampliação */
const box = document.getElementById("lightbox");
const boxImg = document.getElementById("lightbox-img");
document.querySelectorAll("#galeria .foto").forEach(btn => {
  btn.addEventListener("click", () => {
    boxImg.src = btn.dataset.src;
    boxImg.alt = btn.dataset.alt;
    box.showModal();
  });
});
document.getElementById("fechar").addEventListener("click", () => box.close());
box.addEventListener("click", e => { if (e.target === box) box.close(); });

document.getElementById("ano").textContent = new Date().getFullYear();
